const config = {
  BACK_END_HOST: "localhost",
  BACK_END_PORT: 3001
};

export default config;
