const config = {
  BACK_END_HOST: 'localhost',
  BACK_END_PORT: '4000',
  FRONT_END_HOST: 'localhost',
  FRONT_END_PORT: '5000'
};

export default config;
