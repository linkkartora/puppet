const config = {
  BACK_END_PORT: 3001,
  MONGODB_PORT: 27017,
  DB_NAME: "todolist"
};

module.exports = {
  config: config
};
