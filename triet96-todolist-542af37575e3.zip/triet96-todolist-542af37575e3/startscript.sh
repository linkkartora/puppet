#!/bin/bash

#Description

#Start front end server with specified information
#-Input
#++Front-end port

#Global Vars
FRONT_END_PORT_DEFAULT="3000"
FRONT_END_PORT="$1"

#Check port is not empty

if [[ -z "$FRONT_END_PORT" ]]; then
    echo Port is empty, use default port of 3000
    FRONT_END_PORT="$FRONT_END_PORT_DEFAULT"
fi


#Modify port in config file (right now, the Front end port in this file is not used elsewhere)
sed -ri.bak /FRONT_END_PORT/s/".*"/"$FRONT_END_PORT"/ src/config.js

#Modify port in package.json file. This is the command which is used to start the server with specified port
sed -ri.bak "/start/s/PORT=.*react-scripts/PORT="$FRONT_END_PORT" react-scripts/" package.json

#Kill processes Listening on specified port
fuser -k -n tcp "$FRONT_END_PORT"
#Start server
echo Starting server at port "$FRONT_END_PORT"
echo =========================================
npm start >> server_stdout.out 2>> server_stderr.err &