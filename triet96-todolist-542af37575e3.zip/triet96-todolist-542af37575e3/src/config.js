const config = {
  BACK_END_HOST: "127.0.0.1",
  BACK_END_PORT: "3004",
  FRONT_END_HOST: "127.0.0.1"
};

export default config;
